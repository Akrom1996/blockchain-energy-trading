import React, { Component } from 'react';
import axios from 'axios'

class showStats extends Component {
    componentDidMount = () => {
        axios.get('http://localhost:4000/route/getAssets')
            .then(res => console.log(res.data))
            .catch(err => console.log(err))
    }
    render() {
        return (
            <div>
                <h3>Show current existing assets {this.props.username}</h3>
            </div>
        );
    }
}

export default showStats;