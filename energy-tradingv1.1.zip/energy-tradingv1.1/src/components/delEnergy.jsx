import React, { Component } from 'react';

class delEnergy extends Component {
    render() {
        return (
            <div>
                <h3>delete energy</h3>
            </div>
        );
    }
}

export default delEnergy;